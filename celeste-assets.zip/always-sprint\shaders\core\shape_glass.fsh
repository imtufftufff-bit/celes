#version 330

#moj_import <always-sprint:common.glsl>

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform BlurUniforms {
    vec4 Radius;
    vec2 Size;
    float Smoothness;
    float BlurRadius;
    float Time;
};

uniform sampler2D Sampler0;

in vec2 FragCoord;
in vec2 TexCoord;
in vec4 FragColor;

out vec4 OutColor;

const float CornerSmoothness = 2.0;
const float GlobalAlpha = 1.0;
const float FresnelPower = 50.0;
const vec3 FresnelColor = vec3(1.0, 1.0, 1.0);
const float FresnelAlpha = 1.0;
const float BaseAlpha = 1.0;
const bool FresnelInvert = true;
const float FresnelMix = 0.0;
const float DistortStrength = 0.08;

const float TAU = 6.28318530718;
const float STEP = TAU / 16.0;

float rr_roundedBoxSDF(vec2 p, vec2 b, vec4 r, float smoothness) {
    r.xy = (p.x > 0.0) ? r.xy : r.zw;
    r.x = (p.y > 0.0) ? r.x : r.y;
    vec2 q = abs(p) - b + r.x;
    vec2 q_clamped = max(q, 0.0);
    float len = pow(pow(q_clamped.x, smoothness) + pow(q_clamped.y, smoothness), 1.0/smoothness);
    return min(max(q.x, q.y), 0.0) + len - r.x;
}

void main() {
    vec2 center = Size * 0.5;
    vec2 box_half_size = center - 1.0;
    vec2 pos = (FragCoord * Size) - center;

    float distance = rr_roundedBoxSDF(-pos, box_half_size, Radius, CornerSmoothness);
    float alpha = 1.0 - smoothstep(1.0 - Smoothness, 1.0, distance);

    float distToEdge = abs(rr_roundedBoxSDF(pos, box_half_size, Radius, CornerSmoothness));

    float max_dist_norm = min(box_half_size.x, box_half_size.y);
    float edge_gradient = 1.0 - clamp(distToEdge / max_dist_norm, 0.0, 1.0);

    float fresnel;
    float base = FresnelInvert ? edge_gradient : (1.0 - edge_gradient);

    if (FresnelPower > 20.0) {
        fresnel = exp(FresnelPower * log(clamp(base, 0.001, 1.0)));
    } else {
        fresnel = pow(base, FresnelPower);
    }
    fresnel = clamp(fresnel, 0.0, 1.0);

    vec2 dir = normalize(pos);
    dir *= min(vec2(1.0), vec2(Size.x / Size.y, Size.y / Size.x));
    dir = normalize(dir);

    vec2 wave = vec2(sin(TexCoord.y * 20.0 + Time * 3.0), cos(TexCoord.x * 20.0 + Time * 2.5)) * 0.01;

    vec2 distortedTexCoord = TexCoord + dir * fresnel * DistortStrength + wave * fresnel;

    vec2 multiplier = BlurRadius / vec2(textureSize(Sampler0, 0));
    vec3 average = texture(Sampler0, distortedTexCoord).rgb;
    for (float d = 0.0; d < TAU; d += STEP) {
        for (float i = 0.2; i <= 1.0; i += 0.2) {
            average += texture(Sampler0, distortedTexCoord + vec2(cos(d), sin(d)) * multiplier * i).rgb;
        }
    }
    average /= 81.0;

    vec3 finalColor = mix(average, FresnelColor, fresnel * FresnelMix);
    float finalAlpha = mix(BaseAlpha, FresnelAlpha, fresnel) * alpha;

    if (finalAlpha < 0.001) {
        discard;
    }

    OutColor = vec4(finalColor, finalAlpha * GlobalAlpha) * ColorModulator * FragColor;
}
