#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

uniform sampler2D Sampler0;

in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 texColor = texture(Sampler0, texCoord0);

    float dist = length(texCoord0 - 0.5) * 2.0;
    float circleAlpha = 1.0 - smoothstep(0.98, 1.0, dist);
    texColor.a *= circleAlpha;

    if (texColor.a <= 0.001) {
        discard;
    }

    fragColor = texColor * vertexColor * ColorModulator;
}
