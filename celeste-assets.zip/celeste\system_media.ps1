$ErrorActionPreference = 'Stop'

[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime] > $null
[Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime] > $null
try {
    Add-Type -AssemblyName System.Runtime.WindowsRuntime -ErrorAction Stop
} catch {
    # The assembly may already be loaded by the host PowerShell process.
}

# Project WinRT's thumbnail stream through the framework extension method by
# reflection. This stays pure, auditable PowerShell and requires no bundled
# executable bridge or Windows SDK installation.
$asStreamMethod = [System.IO.WindowsRuntimeStreamExtensions].GetMethods() |
    Where-Object {
        $_.Name -eq 'AsStream' -and
        $_.GetParameters().Count -eq 1
    } |
    Select-Object -First 1

function Read-RandomAccessStreamBytes($randomAccess, [long] $maximumBytes) {
    if ($null -eq $asStreamMethod) {
        throw 'Windows Runtime stream projection is unavailable'
    }
    if ($null -eq $randomAccess -or $maximumBytes -lt 1 -or $randomAccess.Size -gt $maximumBytes) {
        throw 'System-media artwork exceeds the allowed size'
    }

    $stream = [System.IO.Stream] $asStreamMethod.Invoke($null, @($randomAccess))
    $memory = [System.IO.MemoryStream]::new()
    try {
        $buffer = [byte[]]::new(81920)
        while (($count = $stream.Read($buffer, 0, $buffer.Length)) -gt 0) {
            if ($memory.Length + $count -gt $maximumBytes) {
                throw 'System-media artwork exceeds the allowed size'
            }
            $memory.Write($buffer, 0, $count)
        }
        return ,$memory.ToArray()
    } finally {
        $memory.Dispose()
        $stream.Dispose()
    }
}

function Await-WinRt($operation, [Type] $resultType) {
    $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and
            $_.IsGenericMethod -and
            $_.GetParameters().Count -eq 1
        } |
        Select-Object -First 1
    $task = $asTask.MakeGenericMethod($resultType).Invoke($null, @($operation))
    $task.Wait()
    return $task.Result
}

function Write-Payload([hashtable] $payload) {
    [Console]::Out.WriteLine(($payload | ConvertTo-Json -Compress -Depth 4))
    [Console]::Out.Flush()
}

function Friendly-Source([string] $source) {
    if ([string]::IsNullOrWhiteSpace($source)) { return 'System media' }
    $lower = $source.ToLowerInvariant()
    if ($lower.Contains('spotify')) { return 'Spotify' }
    if ($lower.Contains('amazonmusic') -or $lower.Contains('amazon music')) { return 'Amazon Music' }
    if ($lower.Contains('youtube')) { return 'YouTube Music' }
    if ($lower.Contains('chrome') -or $lower.Contains('msedge') -or $lower.Contains('firefox')) { return 'Browser media' }
    return [System.IO.Path]::GetFileNameWithoutExtension($source)
}

$manager = Await-WinRt `
    ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) `
    ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
$lastArtworkIdentity = ''

function Current-Session {
    $session = $manager.GetCurrentSession()
    if ($null -eq $session) {
        $script:manager = Await-WinRt `
            ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) `
            ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])
        $session = $manager.GetCurrentSession()
    }
    return $session
}

function Write-State {
    try {
        $session = Current-Session
        if ($null -eq $session) {
            Write-Payload @{
                ok = $true
                available = $false
                message = 'Play something in Spotify, YouTube Music, Amazon Music, or another media app'
            }
            return
        }

        $properties = Await-WinRt `
            ($session.TryGetMediaPropertiesAsync()) `
            ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])
        $playback = $session.GetPlaybackInfo()
        $timeline = $session.GetTimelineProperties()
        $status = $playback.PlaybackStatus.ToString()
        $sourceId = [string] $session.SourceAppUserModelId
        $artworkIdentity = "$sourceId`n$($properties.Title)`n$($properties.Artist)`n$($properties.AlbumTitle)"
        $artworkBase64 = ''
        if ($artworkIdentity -ne $script:lastArtworkIdentity) {
            $script:lastArtworkIdentity = $artworkIdentity
            try {
                if ($null -ne $properties.Thumbnail) {
                    $randomAccess = Await-WinRt `
                        ($properties.Thumbnail.OpenReadAsync()) `
                        ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
                    $artworkBytes = Read-RandomAccessStreamBytes $randomAccess 5242880
                    if ($null -ne $artworkBytes -and $artworkBytes.Length -le 5242880) {
                        $artworkBase64 = [Convert]::ToBase64String([byte[]] $artworkBytes)
                    }
                }
            } catch {
                # Artwork is optional; never fail playback metadata for it.
            }
        }
        $shuffle = $false
        if ($null -ne $playback.IsShuffleActive -and $playback.IsShuffleActive.HasValue) {
            $shuffle = [bool] $playback.IsShuffleActive.Value
        }

        Write-Payload @{
            ok = $true
            available = $true
            source = Friendly-Source $sourceId
            sourceId = $sourceId
            artworkKey = $artworkIdentity
            artworkBase64 = $artworkBase64
            title = [string] $properties.Title
            artist = [string] $properties.Artist
            album = [string] $properties.AlbumTitle
            playing = $status -eq 'Playing'
            shuffle = $shuffle
            progressMs = [long] $timeline.Position.TotalMilliseconds
            durationMs = [long] $timeline.EndTime.TotalMilliseconds
            canPrevious = [bool] $playback.Controls.IsPreviousEnabled
            canToggle = [bool] $playback.Controls.IsPlayPauseToggleEnabled
            canNext = [bool] $playback.Controls.IsNextEnabled
            canShuffle = [bool] $playback.Controls.IsShuffleEnabled
            message = ''
        }
    } catch {
        Write-Payload @{
            ok = $false
            available = $false
            message = [string] $_.Exception.Message
        }
    }
}

function Invoke-Control([string] $command) {
    try {
        $session = Current-Session
        if ($null -eq $session) {
            Write-State
            return
        }
        switch ($command) {
            'TOGGLE' {
                [void] (Await-WinRt ($session.TryTogglePlayPauseAsync()) ([bool]))
            }
            'NEXT' {
                [void] (Await-WinRt ($session.TrySkipNextAsync()) ([bool]))
            }
            'PREVIOUS' {
                [void] (Await-WinRt ($session.TrySkipPreviousAsync()) ([bool]))
            }
            'SHUFFLE' {
                $playback = $session.GetPlaybackInfo()
                $enabled = $false
                if ($null -ne $playback.IsShuffleActive -and $playback.IsShuffleActive.HasValue) {
                    $enabled = [bool] $playback.IsShuffleActive.Value
                }
                [void] (Await-WinRt ($session.TryChangeShuffleActiveAsync(-not $enabled)) ([bool]))
            }
        }
        Start-Sleep -Milliseconds 80
        Write-State
    } catch {
        Write-Payload @{
            ok = $false
            available = $false
            message = [string] $_.Exception.Message
        }
    }
}

while ($true) {
    $command = [Console]::In.ReadLine()
    if ($null -eq $command -or $command -eq 'QUIT') { break }
    switch ($command.Trim().ToUpperInvariant()) {
        'STATE' { Write-State }
        'TOGGLE' { Invoke-Control 'TOGGLE' }
        'NEXT' { Invoke-Control 'NEXT' }
        'PREVIOUS' { Invoke-Control 'PREVIOUS' }
        'SHUFFLE' { Invoke-Control 'SHUFFLE' }
        default {
            Write-Payload @{
                ok = $false
                available = $false
                message = 'Unknown system-media command'
            }
        }
    }
}
