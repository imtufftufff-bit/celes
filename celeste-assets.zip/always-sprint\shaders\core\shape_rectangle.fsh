#version 330

#moj_import <always-sprint:common.glsl>

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform ShapeUniforms {
    vec4 Radius;
    vec2 Size;
    float Smoothness;
};

in vec2 FragCoord;
in vec4 FragColor;

out vec4 OutColor;

void main() {
    vec2 center = Size * 0.5;
    float distance = roundedBoxSDF(center - (FragCoord * Size), center - Smoothness, Radius);

    float alpha = 1.0 - smoothstep(0.0, Smoothness, distance);
    vec4 finalColor = vec4(FragColor.rgb, FragColor.a * alpha);

    if (finalColor.a == 0.0) {
        discard;
    }

    OutColor = finalColor * ColorModulator;
}
