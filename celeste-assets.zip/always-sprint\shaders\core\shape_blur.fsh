#version 330

#moj_import <always-sprint:common.glsl>

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform BlurUniforms {
    vec4 Radius;
    vec2 Size;
    float Smoothness;
    float BlurRadius;
    float Time;
};

uniform sampler2D Sampler0;

in vec2 FragCoord;
in vec2 TexCoord;
in vec4 FragColor;

out vec4 OutColor;

const float TAU = 6.28318530718;
const float STEP = TAU / 16.0;

void main() {
    vec2 multiplier = BlurRadius / vec2(textureSize(Sampler0, 0));

    vec3 average = texture(Sampler0, TexCoord).rgb;
    for (float d = 0.0; d < TAU; d += STEP) {
        for (float i = 0.2; i <= 1.0; i += 0.2) {
            average += texture(Sampler0, TexCoord + vec2(cos(d), sin(d)) * multiplier * i).rgb;
        }
    }
    average /= 81.0;

    vec2 center = Size * 0.5;
    float distance = roundedBoxSDF(center - (FragCoord * Size), center - Smoothness, Radius);
    float alpha = 1.0 - smoothstep(0.0, Smoothness, distance);

    vec4 finalColor = vec4(average, 1.0) * FragColor;
    finalColor.a = FragColor.a * alpha;

    if (finalColor.a == 0.0) {
        discard;
    }
    OutColor = finalColor * ColorModulator;
}
