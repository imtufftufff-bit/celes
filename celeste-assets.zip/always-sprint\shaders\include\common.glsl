

float roundedBoxSDF(vec2 centerPosition, vec2 halfSize, vec4 radius) {
    radius = min(radius, vec4(halfSize.x, halfSize.y, halfSize.x, halfSize.y));
    radius.xy = (centerPosition.x > 0.0) ? radius.xy : radius.zw;
    radius.x = (centerPosition.y > 0.0) ? radius.x : radius.y;
    vec2 q = abs(centerPosition) - halfSize + radius.x;
    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius.x;
}

float squircleSDF(vec2 p, vec2 b, vec4 r, float cornerSmoothness) {
    r.xy = (p.x > 0.0) ? r.xy : r.zw;
    r.x = (p.y > 0.0) ? r.x : r.y;
    vec2 q = abs(p) - b + r.x;
    vec2 qc = max(q, 0.0);
    float len = pow(pow(qc.x, cornerSmoothness) + pow(qc.y, cornerSmoothness), 1.0 / cornerSmoothness);
    return min(max(q.x, q.y), 0.0) + len - r.x;
}

const vec2[4] RECT_VERTICES_COORDS = vec2[](
    vec2(0.0, 0.0),
    vec2(0.0, 1.0),
    vec2(1.0, 1.0),
    vec2(1.0, 0.0)
);

vec2 rvertexcoord(int id) {
    return RECT_VERTICES_COORDS[id % 4];
}
